import React from "react";
import { useQuery } from "@tanstack/react-query";
import { api } from "../lib/api";
import { useLanguages, languageLabel } from "../hooks/useLanguages";
import { Badge, Button, Card, EmptyState, Input, Select, Skeleton } from "../components/ui";

interface HistoryItem {
  id: string; created_at: string; source_language: string; target_language: string;
  source_text: string; translated_text: string; model: string; provider: string;
  latency_ms: number; quality_flags: string[]; kind: string; from_tm: boolean;
}

export default function HistoryPage() {
  const { data: langs } = useLanguages();
  const [q, setQ] = React.useState("");
  const [src, setSrc] = React.useState("");
  const [tgt, setTgt] = React.useState("");
  const [debounced, setDebounced] = React.useState("");

  React.useEffect(() => {
    const t = setTimeout(() => setDebounced(q), 400);
    return () => clearTimeout(t);
  }, [q]);

  const historyQ = useQuery({
    queryKey: ["history", debounced, src, tgt],
    queryFn: () => {
      const p = new URLSearchParams({ limit: "100" });
      if (debounced) p.set("q", debounced);
      if (src) p.set("source_language", src);
      if (tgt) p.set("target_language", tgt);
      return api<HistoryItem[]>(`/api/v1/history?${p}`);
    },
  });

  const del = async (id: string) => {
    await api(`/api/v1/history/${id}`, { method: "DELETE" });
    historyQ.refetch();
  };

  return (
    <div className="mx-auto max-w-5xl space-y-4 p-4 lg:p-6">
      <div>
        <h1 className="text-lg font-bold text-ink-900">Translation history</h1>
        <p className="text-xs text-ink-400">Full-text search across your organization's translations (PostgreSQL FTS adapter).</p>
      </div>
      <div className="flex flex-wrap gap-2">
        <Input className="max-w-xs flex-1" placeholder="Search source or translation…" aria-label="Search history"
               value={q} onChange={(e) => setQ(e.target.value)} />
        <Select aria-label="Filter source language" className="w-40" value={src} onChange={(e) => setSrc(e.target.value)}>
          <option value="">Any source</option>
          {(langs ?? []).map((l) => <option key={l.code} value={l.code}>{l.name}</option>)}
        </Select>
        <Select aria-label="Filter target language" className="w-40" value={tgt} onChange={(e) => setTgt(e.target.value)}>
          <option value="">Any target</option>
          {(langs ?? []).map((l) => <option key={l.code} value={l.code}>{l.name}</option>)}
        </Select>
      </div>

      {historyQ.isLoading ? (
        <Card><div className="space-y-3">{[...Array(5)].map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}</div></Card>
      ) : (historyQ.data ?? []).length === 0 ? (
        <Card><EmptyState title="Nothing here yet" body="Translations you run will be stored here with model, latency and quality metadata." icon="⧗" /></Card>
      ) : (
        <div className="space-y-2">
          {(historyQ.data ?? []).map((h) => (
            <div key={h.id} className="gt-card p-4">
              <div className="mb-1.5 flex flex-wrap items-center gap-2 text-[11px] text-ink-400">
                <Badge>{languageLabel(langs, h.source_language)} → {languageLabel(langs, h.target_language)}</Badge>
                <Badge tone="neutral">{h.kind}</Badge>
                {h.from_tm && <Badge tone="good">translation memory</Badge>}
                <span>{h.provider} · {h.model}</span>
                <span>{Math.round(h.latency_ms)} ms</span>
                <span>{new Date(h.created_at).toLocaleString()}</span>
                <div className="flex-1" />
                {h.quality_flags.map((f) => <Badge key={f} tone={f.includes("untranslated") ? "bad" : "neutral"}>{f.replace(/_/g, " ")}</Badge>)}
                <Button size="sm" variant="ghost" onClick={() => del(h.id)} aria-label="Delete history item">Delete</Button>
              </div>
              <p className="text-sm text-ink-500">{h.source_text}</p>
              <p className="mt-0.5 text-sm font-medium text-ink-900">{h.translated_text}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
